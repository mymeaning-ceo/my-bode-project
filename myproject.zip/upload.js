// upload.js

require('dotenv').config(); // ← 이거 반드시 있어야 함

const multer = require('multer');
const multerS3 = require('multer-s3');
const {
  S3Client,
  HeadBucketCommand,
  CreateBucketCommand
} = require('@aws-sdk/client-s3');

const s3 = new S3Client({
  region: 'ap-northeast-2',
  credentials: {
    accessKeyId: process.env.S3_KEY,
    secretAccessKey: process.env.S3_SECRET,
  }
});

const bucketName = process.env.S3_BUCKET_NAME;
if (!bucketName) {
  throw new Error('S3_BUCKET_NAME environment variable is not set');
}
console.log("S3_BUCKET_NAME:", `"${process.env.S3_BUCKET_NAME}"`);
console.log('📦 현재 사용 중인 S3 버킷 이름:', `"${process.env.S3_BUCKET_NAME}"`);



async function ensureBucketExists() {
  try {
    await s3.send(new HeadBucketCommand({ Bucket: bucketName }));
  } catch (err) {
    if (err.$metadata && err.$metadata.httpStatusCode === 404) {
      await s3.send(new CreateBucketCommand({
        Bucket: bucketName,
        CreateBucketConfiguration: { LocationConstraint: 'ap-northeast-2' }
      }));
    } else {
      console.error('Error checking bucket:', err);
    }
  }
}

// Fire and forget check when module loads
// ensureBucketExists().catch((err) => {
//   console.error('Failed to ensure bucket exists', err);
// });

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: process.env.S3_BUCKET_NAME,
    key: function (req, file, cb) {
      cb(null, Date.now().toString() + '-' + file.originalname);
    }
  })
});

module.exports = upload;
